
#include "apue.h"
#include <signal.h>

static void handler1 (int);
static void handler2 (int);

int main(int argc, char * argv[]) {
    int i,pid;
    if (argc != 2) {
        printf("Errore! Uso: ./a.out <valore x>\n");
        exit(1);
    }
    int x = atoi(argv[1]);

    pid = fork();
    if (pid==-1) {
        fprintf(stderr,"fork fallita\n");
        exit(1);
    }
    else if (pid==0) {
        printf("SONO FIGLIO1 %d ASPETTO 3 secondi e mando un segnale a %d\n",getpid(),getppid());
        if (x%2 == 0) {
            sleep(3);
            kill(getppid(),SIGUSR1);
            printf("X: %d , sono il figlio1 e avviso padre\n",x);
        }
        //printf("\nRIp figlio1");
        exit(0);

    }else {
        signal(SIGUSR1,handler1);
        printf("PADRE %d INIZIO",getpid());
        for (i=0;i<3;i++) {
            sleep(1);
            printf(".\n");
        }
        //printf("\nRIP PADRE\n");
        }
    int pid2 = fork();
        if (pid2==-1) {
            fprintf(stderr,"fork fallita\n");
            exit(1);
        } else if (pid2==0) {
            printf("SONO FIGLIO2 %d ASPETTO 3 secondi e mando un segnale a %d\n",getpid(),getppid());
            if (x%2 == 1) {
                sleep(3);
                kill(getppid(),SIGUSR2);
                printf("X: %d , sono il figlio2 e avviso padre\n",x);
            }
           // printf("\nRIp figlio1");
            exit(0);


        }else {
            signal(SIGUSR2,handler2);
            printf("PADRE %d INIZIO",getpid());
            for (i=0;i<3;i++) {
                sleep(1);
                printf(".\n");
            }

            //printf("\nRIP PADRE\n");

            ;}
}

static void handler1 (int signo) {
    if (signo == SIGUSR1) {
        printf("\n padre RICEVUTO INTERRUPT DAL FIGLIO1 \n");
    }
    return;
}
static void handler2 (int signo) {
    if (signo == SIGUSR2) {
        printf("\n padre RICEVUTO INTERRUPT DAL FIGLIO2  \n");
    }
    return;
}
