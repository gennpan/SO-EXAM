#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
//kill è chi invia il segnale
//signal per poterlo gestire
//per inviare un segnale a me stesso uso raise


void handler(int SIGNO) {
	printf("Ricevuto %d",getpid());
}


int main(int argc, char* argv[]) {

	if(argc != 2) {
		printf("errore devi inserire <Carattere>");
		return 1;
	}

    char carattere = argv[1][0];

	if(carattere == 'p' || carattere == 'm'){
	} else {
		printf("Devi inserire 'p' o 'm'");
		return 1;
	}

	printf("carattere %c\n",carattere);
	int M = 6;
	pid_t pid[M];
	
	for(int i=0;i<M;i++){
		pid[i]=fork();
        if (pid[i] == 0) {
		if(carattere == 'p' && i%2 == 0){
			sleep(1); //devo aspettare che il mio successivo venga creato
			printf("Invio Segnale");
			kill(pid[i+1],SIGUSR1);		//perchè quì sto dicendo che lo mando al successivo
		}

		else if(carattere == 'p' && i%2 == 1) {
			signal(SIGUSR1,handler);
			sleep(3);
		}

		if ( carattere == 'm' && i< M/2) {
			sleep(1);
			printf("Invio Segnale");
			kill(pid[M/2+1],SIGUSR1);
		}
		else if (carattere == 'm' && i>=M/2) {
			signal(SIGUSR1,handler);
			sleep(3);
		}
		exit(1);
        }
	}
	sleep(7);
	return 0;
}


	
	
	



