/*Si realizzi un programma in C che preso un intero N come parametro da riga di comando (compreso tra 1 e 100)
generi due figli f1 e f2 e proceda come segue:
Se il paramentro N è pari il programma invia il segnale SIGUSR1 al figlio f1 che calcola la sommma tra il valore del suo PID e quello del processo padre. Il processo f2 stamperà solo il suo pid. Se il parametro N è dispari il programma invia il segnale SIGUSR2 al figlio f2 che calcola la differenza tra il valore del pid del processo padre e il suo pid. Il processo f1 stamperà solo il suo pid. Alla fine il processo principale calcolerà e stamperà il prodotto dei pid dei due processi figli f1 e f2 e terminerà stampando un messaggio di salute.*/

#include "apue.h"
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define MIN  1
#define MAX  100




static void f1_handler(int signo) {     

    if (signo == SIGUSR1) {

        pid_t pid = getpid();
        pid_t Ppid = getppid();
        int sum = pid + Ppid;
        printf("Somma pid e ppid = %d\n",sum);
    }

}
static void f2_handler(int signo) {

    if (signo == SIGUSR2) {

        pid_t pid = getpid();
        pid_t Ppid = getppid();
        int diff = Ppid - pid ;
        printf("Differenza ppid e pid = %d\n",diff);
    }

}

int main (int argc, char *argv[]) {

    printf("\nInizio processo sono il padre: %d\n",getpid());

    if (argc != 2) {
        printf("Inserire un intero N compreso tra 1 e 100!\n");
        exit(1);
    }

    int n = atoi(argv[1]);
        int status;
        pid_t pid1,pid2;

    if ( n < 1 ) n = MIN;
    else if (n>100) n = MAX;

    pid1 = fork();
    if(pid1 < 0) {
        printf("Errore creazione figlio!\n");
        exit(1);
    }else if (pid1 == 0) {
        //SONO IL FIGLIO
        //FACCIO
        printf("Sono il figlio 1 con pid %d\n",getpid());
        signal(SIGUSR1,f1_handler);
        printf("Sono in attesa del segnale. Attendo 5 secondi\n");
        sleep(5);
        exit(0);
    }

       pid2 = fork();

    if(pid2 < 0) {
        printf("Errore creazione figlio!\n");
        exit(1);
    }else if (pid2 == 0) {
        //SONO IL FIGLIO
        //FACCIO
        printf("Sono il figlio 2 con pid %d\n",getpid());
        signal(SIGUSR2,f2_handler);
        sleep(5);
        exit(0);
    }
        sleep(5);
    if (n%2 == 0) {
        kill(pid1,SIGUSR1);
        printf("Mando segnale 1\n");
    }else {
        kill(pid2,SIGUSR2);
    }


    waitpid(pid1, NULL, 0);
    int prod = pid2*pid2;
    printf("Figlio1: %d \nFIglio2: %d\n",pid1,pid2);
    printf("Il prodotto dei pid dei miei figli è : %d\n\n",prod);
    return 0;
}

