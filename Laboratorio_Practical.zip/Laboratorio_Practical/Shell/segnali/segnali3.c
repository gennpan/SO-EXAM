#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>


//kill è chi invia il segnale
//signal per poterlo gestire

void handler(void * SIGNO){
    printf("RICEVUTO: %d", getpid());
}


int main(int argc, char *argv[]){

    if(argc != 2){
        perror("Errore devi inserire un carattere.");
    }

    char n;
    strcpy(c, argv[1]);
    pid_t pid;

    for()
    pid = fork();

    if(pid == 0 && c == 'p'){
        kill(pid)               
    }

}