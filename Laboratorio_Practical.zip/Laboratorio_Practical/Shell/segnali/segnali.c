#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>

//kill è chi invia il segnale
//signal per poterlo gestire

int main(int argc, char* argv[]) {
    if (argc != 3) {
        printf("Utilizzo: %s [p/m] M\n", argv[0]);
        return 1;
    }
    
    char type = argv[1][0];
    int M = atoi(argv[2]);
    
    if (M % 2 != 0) {
        printf("Il numero M deve essere pari.\n");
        return 1;
    }
    
    pid_t* child_pids = malloc(M * sizeof(pid_t));
    int i;
    
    // Crea M processi figli
    for (i = 0; i < M; i++) {
        pid_t pid = fork();
        
        if (pid == 0) {
            // Processo figlio
            if ((type == 'p' && i % 2 == 0) || (type == 'm' && i < M / 2)) {
                // Invia il segnale SIGUSR1
                kill(getppid(), SIGUSR1);
            }
            
            exit(0);
        } else if (pid > 0) {
            // Processo padre
            child_pids[i] = pid;
        } else {
            printf("Errore nella creazione del processo figlio.\n");
            return 1;
        }
    }
    
    // Gestisci il segnale SIGUSR1 nel processo padre
    int count = 0;
    struct sigaction sa;
    sigset_t mask;
    
    sigemptyset(&mask);
    sa.sa_mask = mask;
    sa.sa_flags = 0;
    sa.sa_handler = SIG_IGN;
    sigaction(SIGUSR1, &sa, NULL);
    
    while (count < M / 2) {
        sigsuspend(&mask);
        count++;
    }
    
    printf("Il processo padre ha ricevuto %d segnali SIGUSR1.\n", count);
    
    // Termina i processi figli
    for (i = 0; i < M; i++) {
        kill(child_pids[i], SIGTERM);
    }
    
    // Attendi la terminazione dei processi figli
    for (i = 0; i < M; i++) {
        wait(NULL);
    }
    
    free(child_pids);
    
    return 0;
}