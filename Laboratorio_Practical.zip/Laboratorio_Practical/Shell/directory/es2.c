/*Creare un link simbolico con il comando ln -s.
Scrivere un programma che selezioni il link nella
directory e stampi a video il nome del file.*/



#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <dirent.h>

#define BUFF 4048

int main(){

    DIR *fd;        //il nome della directory (questo file fd può contenere una directory)
    struct dirent *dirp;        //contiene info della directory che per ora non conosciamo (si utilizza sempre con le directory, include delle variabili)
    struct stat link;        //contiene info del FILE, può essere riempita da file
    char buff[BUFF];  

    getcwd(buff,BUFF); //copia un pat name assoluto della directory corrente nell'array puntato da buff[BUFF]

    fd=opendir(buff); //apri la dir

    while((dirp=readdir(fd)) != NULL){      //readdir legge i file nella directory, finchè leggi qualcosa..
        lstat(dirp->d_name, &link);     //ritorna le informazioni relative al link simbolico ma non a chi punta, copia d_name in &link
        if(S_ISLINK(link.st_mode)){   //se sei un link simbolico 
            printf("link simbolico è: %s\n", dirp->d_name);
        }
    }       

   closedir(fd); 
   return 0;

}


