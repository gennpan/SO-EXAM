/*Pssata da riga di comando una directory, stampa il file più piccolo, la sua data di ultimo accesso,
il suo size e i suoi permessi, solo se è regolare e se è il più piccolo appunto.*/
#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <sys/stat.h>
#include <string.h>
#include <time.h>
#include <unistd.h>


int main(int argc, char * argv[]){

	DIR *dp;
	struct dirent *dirp;
	struct stat file;	//è il file su cui effettuiamo il controllo: se è regolare e se è il minimo
	struct stat minimo;	//è il file di cui vogliamo info, quindi il file regolare e minimo
	char buff[256];
	char nome[256];
	char path[256];
	
	if(argc != 2){		//passo da riga di comando per cui verifico che l'utente dia il path
		printf("Errore uso ./a.out <path>\n");
		exit(-1);
	}
	
	strcpy(buff,argv[1]);	//copio il path dell'utente in buff
	long int min = 0;	//serve solo per il controllo...
	dp = opendir(buff);	//apro la directory salvata in buff, ovvero quella che abbiamo copiato in buff
	
	
	while((dirp = readdir(dp))!= NULL){	//finchè la leggi..
		printf("%s", dirp->d_name);
		strcpy(path,buff);
		strcat(path,"/");
		strcat(path,dirp->d_name);
		stat(path,&file);
		if(min == 0){
			min = file.st_size;
		}
		
		if(S_ISREG(file.st_mode) && file.st_size < min){
			min = file.st_size;
			strcpy(nome,dirp->d_name);
			minimo = file;
		
		}
	}
	printf("\n\nIl più piccolo è: %s\nHa come data di ultimo accesso: %sHa come size: %d\nHa come permessi: %d\n",nome,ctime(&minimo.st_atime),minimo.st_size,minimo.st_mode & 07777);	
	//minimo.st_mode & 07777 questa AND, ci permette di stampare i permessi in maniera pulita, otteniamo permessi in ottale 
	//che dovranno essere interpretati da noi, sono 3 numeri in output perchè abbiamo RWX.

	closedir(dp);	//chiudo
	exit(0);	//esco
}
