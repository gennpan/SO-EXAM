/*#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>

//faccio la maschera su st_mode perchè è lì che ho i permessi in ottale
//devo quindi fare una sorta di cast.

//in questo caso gli devo passare solo il path per un file specifico, non ho quindi bisogno di DIR

#define N 4098  //definisco una costante N, in teoria basterebbe 256...


int main(int argc, char * argv[]){

      if(argc != 2){
        perror("Devi passare il path.");
        return 1;
    }

    //DIR *pd; non serve
    struct stat pluto;

    char buff[N];   //per passare il path, infatti è un array di char 
    strcpy(buff,argv[1]);   //dato che è una stringa, ho bisogno della strcpy 


    lstat(buff,&pluto);   //passo il path conservato nel buffer e l'indirizzo della stat pluto
    printf("\npath:[%s]  size:[%ld]  permissions(modes):[%o]\n", buff, pluto.st_size, pluto.st_mode & 07777);  //st_mode per vedere tutti i permessi

    return 0;
}

*/
//Dalla directory corrente stampo tutti i file con nome, size e permessi associati.
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#include <dirent.h>

//faccio la maschera su st_mode perchè è lì che ho i permessi in ottale
//devo quindi fare una sorta di cast.

//in questo caso gli devo passare solo il path per un file specifico, non ho quindi bisogno di DIR

#define BUFF 4098  //definisco una costante N, in teoria basterebbe 256...


int main(int argc, char * argv[]){


    DIR *pd; 
    char buff[BUFF];   //per passare il path, infatti è un array di char
    struct stat link;
    struct dirent *dirp;
    //int m = strtol(argv[1], NULL, 8);  //permessi in base 8

    getcwd(buff, BUFF);
    pd = opendir(buff);

    while((dirp = readdir(pd)) != NULL) {
     // if(S_IFREG(dirp->d_name))     //se mi chiede che devo stampare info solo dei file regolari
      printf("[%s]  [%ld]  [%o]\n", dirp->d_name, link.st_size, link.st_mode);
    }

    closedir(pd);
    return 0;
}