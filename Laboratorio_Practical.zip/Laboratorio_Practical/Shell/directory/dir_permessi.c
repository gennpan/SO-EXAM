
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <dirent.h>

#define buffer 4098

int main(int argc, char* argv[]) {
	DIR *fd; //questo file fd può contenere una directory
	struct dirent *pippo; //si utilizza sempre con le directory include delle variabili
	struct stat pluto; //può essere riempita da file;
	char buff[buffer]; 
	getcwd(buff,buffer); //copia un pat name assoluto della directory corrente nell'array puntato da buff[buffer]
	fd = opendir(buff); //apri la dir
	while((pippo = readdir(fd)) != NULL) {
		lstat(pippo->d_name,&pluto);//ritorna le informazioni relative al link simbolico ma non a chi punta
		if(S_ISREG(pluto.st_mode) && (pluto.st_mode == S_IWGRP)) { //se sei un link simbolico
			printf("Permessi del file: ");
			printf("\n");
			printf("file regolare %s", pippo->d_name);
  			printf((S_ISDIR(pluto.st_mode)) ? "d" : "-");
  			printf((pluto.st_mode & S_IRUSR) ? "r" : "-");
    		printf((pluto.st_mode & S_IWUSR) ? "w" : "-");
    		printf((pluto.st_mode & S_IXUSR) ? "x" : "-");
    		printf((pluto.st_mode & S_IRGRP) ? "r" : "-");
   			printf((pluto.st_mode & S_IWGRP) ? "w" : "-");
   			printf((pluto.st_mode & S_IXGRP) ? "x" : "-");
    		printf((pluto.st_mode & S_IROTH) ? "r" : "-");
    		printf((pluto.st_mode & S_IWOTH) ? "w" : "-");
    		printf((pluto.st_mode & S_IXOTH) ? "x" : "-");
    		printf("\n");	
		}
	}
	closedir(fd);
	return 0;
}
