/*Si realizzi un programma in C e Posix sotto Linux che presi due parametri da riga di comando 
(il primo parametro sarà il percorso di una directory e secondo sara un numero intero che 
rappresenta i permessi nel
rormaro occaic
relativi al file) faccia il parsing della directory passato come primo argomento e stampi i 
nomi, i permessi e la data di ultima modifica dei file contenuti in tale directory per cui i 
permessi corrispondono a quanto speci nel secondo parametro
Ad esempio, se il programma viene lanciato in questo modo:
/a.out /usr/local/bin/ 4755
il programma stampera il nome, i permessi e la data di ultima modifica di ogni file presente 
nella directory /usr/local/bin/ che avranno i permessi seguenti: DIt di set-uid settato, 
lettura+scrittura + esecuzione per proprietario, lettura+esecuzione sia per il gruppo che per 
tutti qli altri utenti del sistema.

Oppure, come ulteriore esempio, se il programma viene lanciato in questo modo:
./a.out /sbin/ 644
il programma stamperà il nome, i permessi e la data di ultima modifica di ogni file presente 
nella directory /sbin/ che avranno I permessi seguenti: lettura+scrittura per il proprietario, 
ettura sia per il gruppo che per tutti gli altri utenti del sistema.*/





#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <dirent.h>
#include <string.h> //per la strcopy
#include <time.h>   //per ctime

#define buffer 4098

int main(int argc, char * argv[]){

    if(argc != 3){
        printf("Devi passare almeno due valori.\n");
        exit(-1);
    }


    DIR *pd;    //la usiamo solo per la directory corrente, contiene il nome della directory 
    struct stat file;
    struct dirent *dir;
    int perm;
    char path[256];


    strcpy(path,argv[1]);
    perm = atoi(argv[2]);


    int permissions = strtol(argv[2], NULL, 0);
    printf("path: %s Permessi: %o\n\n", path, permissions);

    pd = opendir(path);


    while((dir=readdir(pd)) != NULL){      //readdir legge i file nella directory, finchè leggi qualcosa..
        
        char file_path[256];
        strcpy(file_path,path);
        strcat(file_path,"/");
        strcat(file_path,dir->d_name);

        time_t modified_time = file.st_mtime;
            char *time = ctime(&modified_time);

        stat(file_path,&file);
        printf("Nome: [%s], modes: [%o] --- time: %s\n\n", dir->d_name,(file.st_mode& 07777), time);
       
        if((file.st_mode & 07777) == permissions) {

            printf("Nome %s, modes: [%04o], time: %s\n\n", dir->d_name,(file.st_mode& 07777), time);
        } 
    }       

   closedir(pd); 
   return 0;

}


