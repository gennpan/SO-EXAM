/*ls -l | sort | wc -c*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>



int main (int argc, char * argv[]){


    int pd[2];
    int pd2[2];
    pipe(pd);
    pipe(pd2);
    pid_t pid;
    pid_t pid2;

    pid = fork();
    if(pid == 0){
        close(pd[0]);
        dup2(pd[1],1);
        close(pd[1]);
        execlp("ls", "ls", "-l", NULL);
    }

    pid2 = fork();
    if(pid2 == 0){
        close(pd[1]);
        dup2(pd[0],0);
        close(pd[0]);

        close(pd2[0]);
        dup2(pd2[1],1);
        close(pd2[1]);
        execlp("sort", "sort", NULL);
    }

        close(pd[0]);
        close(pd[1]);

        close(pd2[1]);
        dup2(pd2[0],0);
        close(pd2[0]);
        execlp("wc", "wc","-c", NULL);

    return 0;

}
