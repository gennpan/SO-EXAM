#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

#define R 0
#define W 1

/*La exec() non cambia la tavola dei descrittori ma si perdono le
variabili locali: come fare per accedere alla stessa pipe se gli
unici riferimenti comuni erano in variabili locali? (pfd)*/

int main(int argc, char* argv[]) {
 
    int pfd[2], pid;
    
    if(pipe(pfd)==-1){                                                                  //creo una pipe anonima
        perror("pipe() fallita"); 
        exit(-1);
    }
 
    if((pid=fork()) < 0) {                                                                  //creo un processo figlio
        perror("fork() fallita"); 
        exit(-2);
    }
 

    if(pid==0) {                                                                            /*figlio*/
        close(pfd[W]);                                                                      /*chiudo la scrittura perche leggo*/
        dup2(pfd[R],0);                                                                     /*duplico la lettura sul file descriptor 0, standard input*/
        close(pfd[R]);                                                                      /*lo chiudo perche l'ho duplicato*/
        execlp("grep","grep",argv[1],NULL);
        perror("grep fallita");
        exit(-3);
    }
    else {                                                                          /*padre*/
        close(pfd[R]);                                                                                  /*chiudo la scrittura perche leggo*/
        dup2(pfd[W],1);                                                                             /*duplico la scrittura sullo standard output 1*/
        close(pfd[W]);                                                          /*chiudo perche duplicato e non mi serve*/
        execlp("ls","ls",argv[2],NULL);                                                                  //il figlio realizza il comando ls effettuando la exec (“ls”,”ls”)
        perror("ls fallita");   
        exit(-4);
    }
 exit(0);
}


//N.B.: la execlp,per implementare un solo comando come ls, prende una stringa ls 2 VOLTE!
//      argv[1] e argv[2] ci servono per passare da linea di comando