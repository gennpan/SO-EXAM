#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>


//ogni stanghetta deco fare un altro fd2 ecc pid2 pipe2 ecc
//l'else quando non lo fa, è perchè esce dall'if e quindi lo faccio in fondo.
//il padre congiunge i due figli e DEVE STAMPARE
int main(int argc, char* argv[]) {
    int pd[2];
    pid_t pid;
    pipe(pd);
   

    pid = fork();
    if (pid == 0) {
        // Processo figlio 1
        close(pd[0]);
        dup2(pd[1], 1);
        close(pd[1]);
        execlp("ls", "ls", "-l", "/", NULL);
    } else {
        close(pd[1]);
        dup2(pd[0], 0);
        close(pd[0]);
        execlp("sort", "sort", NULL);
    }


    return 0;
}