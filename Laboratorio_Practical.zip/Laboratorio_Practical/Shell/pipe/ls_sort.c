#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>


int main(int argc, char* argv[]) {
    int fd1[2];
    int fd2[2];
    int fd3[2];
    pipe(fd1);
    pipe(fd2);
    pipe(fd3);
    pid_t pid1, pid2, pid3;

    pid1 = fork();
    if (pid1 == 0) {
        // Processo figlio 1
        close(fd1[0]);
        dup2(fd1[1], 1);
        close(fd1[1]);
        execlp("ls", "ls", "-la", "/", NULL);
    }

    pid2 = fork();
    if (pid2 == 0) {
        // Processo figlio 2 e fino a qua è una normale pipe!
        close(fd1[1]);
        dup2(fd1[0], 0);
        close(fd1[0]);


        close(fd2[0]);
        dup2(fd2[1],1);
        close(fd2[1]);

        execlp("sort", "sort", NULL);
    }

    close(fd1[1]);
    close(fd1[0]);

    pid3 = fork();
    if (pid3 == 0) {
        // Processo figlio 3
        close(fd2[1]);
        dup2(fd2[0], 0);
        close(fd2[0]);

        close(fd3[0]);
        dup2(fd3[1],1);
        close(fd3[1]);

        execlp("tail", "tail", "-10", NULL);
    }

    // Processo padre
    close(fd2[0]);
    close(fd2[1]);

    close(fd3[1]);
    dup2(fd3[0], 0);
    close(fd3[0]);
    execlp("wc", "wc", "-l", NULL);

    return 0;
}