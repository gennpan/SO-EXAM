/*Scrivere un programma C e Posix che prende da riga di comando N interi compresi tra 5 e 20. Il valore di N è costante indicato nel sorgente.
    Il programma avvia N thread che hanno il seguente comportamento:
    A) Ogni thread va in sospensione ( invocando la funzione sleep()) per un numero di secondi pari al valore del 
        corrispondente parametro e poi stampa il suo indice.
    b) Alla fine del periodo di attesa (sleep), ogni thread stampa un messaggio: "Thread #: svegliato !”
    c) Tutti i thread si sincronizzano tra di loro (utilizzando i semafori basati su memoria)
    D) Dopo aver atteso il termine  di tutti gli altri thread, ciascun thread scrive sullo schermo che ha terminato (“Thread#: terminato…”)
*/




#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <semaphore.h>


#define N 5 // Numero di thread


sem_t semaphores[N]; // Array di semafori per la sincronizzazione dei thread

void* thread_function(void* arg) {
    
    int thread_index = *(int*)arg;
    int sleep_time = 5 + rand() % 16; // Genera un numero casuale tra 5 e 20
    
    printf("Thread %d in sospensione per %d secondi\n", thread_index, sleep_time);
    sleep(sleep_time); // Mette il thread in sospensione
    
    printf("Thread %d svegliato!\n", thread_index);
    
    // Sincronizzazione dei thread
    sem_wait(&semaphores[thread_index]); // Attende che il semaforo del proprio thread diventi 0
    sem_post(&semaphores[(thread_index + 1) % N]); // Incrementa il semaforo del thread successivo
    
    printf("Thread %d terminato...\n", thread_index);
    
    pthread_exit(NULL);
}



int main() {
    
    pthread_t threads[N];
    int thread_ids[N];
    
    srand(time(NULL)); // Inizializza il generatore di numeri casuali
    
    // Inizializza i semafori
    for (int i = 0; i < N; i++) {
        sem_init(&semaphores[i], 0, 0);
    }
    
    // Crea i thread
    for (int i = 0; i < N; i++) {
        thread_ids[i] = i;
        pthread_create(&threads[i], NULL, thread_function, &thread_ids[i]);
    }
    
    // Avvia la sincronizzazione dei thread
    sem_post(&semaphores[0]); // Incrementa il semaforo del primo thread
    
    // Attende la terminazione dei thread
    for (int i = 0; i < N; i++) {
        pthread_join(threads[i], NULL);
    }
    
    // Dealloca i semafori
    for (int i = 0; i < N; i++) {
        sem_destroy(&semaphores[i]);
    }
    
    return 0;
}














































/*
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

#define MIN_VALUE 5
#define MAX_VALUE 20
#define N_THREADS 3 // Esempio con 3 thread

sem_t semaphore;
int threads_completed = 0;

void* thread_function(void* arg) {
    int index = *(int*)arg;
    int sleep_time = (rand() % (MAX_VALUE - MIN_VALUE + 1)) + MIN_VALUE;
    
    sleep(sleep_time);
    printf("Thread %d: svegliato!\n", index);
    
    sem_wait(&semaphore);
    threads_completed++;
    sem_post(&semaphore);
    
    while (threads_completed < N_THREADS) {
        // Aspetta che tutti i thread abbiano terminato
    }
    
    printf("Thread %d: terminato...\n", index);
    
    pthread_exit(NULL);
}

int main(int argc, char* argv[]) {
    if (argc != N_THREADS + 1) {
        printf("Errore: specificare esattamente %d interi come argomenti.\n", N_THREADS);
        return 1;
    }
    
    pthread_t threads[N_THREADS];
    int thread_args[N_THREADS];
    int i;
    
    // Inizializza il semaforo
    sem_init(&semaphore, 0, 1);
    
    // Crea i thread
    for (i = 0; i < N_THREADS; i++) {
        thread_args[i] = atoi(argv[i + 1]);
        pthread_create(&threads[i], NULL, thread_function, &thread_args[i]);
    }
    
    // Aspetta che tutti i thread terminino
    for (i = 0; i < N_THREADS; i++) {
        pthread_join(threads[i], NULL);
    }
    
    // Dealloca il semaforo
    sem_destroy(&semaphore);
    
    return 0;
}
*/