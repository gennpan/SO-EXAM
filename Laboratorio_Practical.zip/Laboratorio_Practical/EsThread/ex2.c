/*Si realizzi un programma in C e Posix utilizzi k thread per calcolare la somma di due matrici kxm e mxp. Non appena sar� calcolata la matrice prodotto, un k+1-esimo thread aggiuntivo, che era rimasto in attesa, provvede a stampare la matrice risultato. Le matrici devono essere allocate dinamicamente.*/


#include <stdlib.h>
#include <stdio.h>
#include <semaphore.h>
#include <pthread.h>
#include <fcntl.h>

struct {
	pthread_mutex_t mutex;
	pthread_cond_t cond;
	sem_t* sem;
	int** Matrix;
	int** Matrix1;
	int** Matrix2;
	int k;
	int m;
	int p;
	int l;
} shared = { PTHREAD_MUTEX_INITIALIZER, PTHREAD_COND_INITIALIZER };

void* func(void* arg);
void* func1(void* arg);

int main(int argc, char* argv[]) {

	if (argc != 4) {
		printf("Errore devi inserire 3 numeri");
		return 1;
	}

	shared.k = atoi(argv[1]);
	shared.m = atoi(argv[2]);
	shared.p = atoi(argv[3]);

	sem_unlink("/my_semaphore");
	sem_close(shared.sem);

	shared.sem = sem_open("/my_semaphore", O_CREAT, 0644, 1);

	shared.Matrix2 = (int**)malloc(shared.k * sizeof(int*));
	for (int i = 0; i < shared.k; i++) {
		shared.Matrix2[i] = (int*)malloc(shared.m * sizeof(int));
	}


	shared.Matrix = (int**)malloc(shared.k * sizeof(int*));
	for (int i = 0; i < shared.k; i++) {
		shared.Matrix[i] = (int*)malloc(shared.m * sizeof(int));
	}
	for (int i = 0; i < shared.k; i++) {
		for (int j = 0; j < shared.m; j++) {
			shared.Matrix[i][j] = rand() % 10;
			printf("[%d]", shared.Matrix[i][j]);
		}
		printf("\n");
	}

	printf("\n");

	shared.Matrix1 = (int**)malloc(shared.m * sizeof(int*));
	for (int i = 0; i < shared.m; i++) {
		shared.Matrix1[i] = (int*)malloc(shared.p * sizeof(int));
	}

	for (int i = 0; i < shared.m; i++) {
		for (int j = 0; j < shared.p; j++) {
			shared.Matrix1[i][j] = rand() % 10;
			printf("[%d]", shared.Matrix1[i][j]);
		}
		printf("\n");
	}

	

	pthread_t tids[shared.k];
	for (int i = 0; i < shared.k; i++) {
		//int* index = (int *)malloc(shared.k * sizeof(int));
		int index = shared.k;
		pthread_create(&tids[i], NULL, func, (void*)&shared);
	}

	pthread_t tid;
	pthread_create(&tid, NULL, func1, NULL);

	pthread_join(tid, NULL);
	sem_unlink("/my_semaphore");
	sem_close(shared.sem);

	return 0;

}

void* func(void* arg) {
	int index = *(int*)arg;
	sem_wait(shared.sem);
	shared.l = 0;
	for (int i = 0; i < shared.k; i++) {
		for (int j = 0; j < shared.p; j++) {
			shared.Matrix2[i][j] += shared.Matrix[i][j] * shared.Matrix1[j][i];

		}
		printf("\n");

	}
	shared.l++;
	sem_post(shared.sem);
	shared.l = 1;
		pthread_cond_signal(&shared.cond);
	

	pthread_exit(NULL);
}

void* func1(void* arg) {
	//controllo
	while (shared.l ==0) {
		pthread_cond_wait(&shared.cond, &shared.mutex);
	}
	for (int i = 0; i < shared.k; i++) {
		for (int j = 0; j < shared.p; j++) {
			printf("[%d]", shared.Matrix2[i][j]);
		}
		printf("\n");
	}
	pthread_mutex_unlock(&shared.mutex);
	pthread_exit(NULL);
}