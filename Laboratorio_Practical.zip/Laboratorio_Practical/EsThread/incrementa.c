/*Scrivere un programma in C che (in ambiente Linux e utilizzando la libreria pthread) crei 2 thread che eseguono
la funzione “incrementa” che a  sua volta accede alle variabili glob.a e glob.b di una  struttura dati condivisa glob e
ne incrementi il loro valore di 1 per 100 volte. Al termine, quando i due thread avranno terminato con gli incrementi, 
il thread principale stamperà a video i valori delle variabili test.a e test.b. Per la gestione della
sincronizzazione si utizzino i mutex allocati dinamicamente*/


#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>


//#define N 2

//PRIMA PARTE

//1. Eventuale Struttura dati condivisa    
struct GlobalData {
    int a;
    int b;
};



//2. Mutex per la sincronizzazione
pthread_mutex_t mutex;  //lo chiamo con &mutex in un block/unlock



//3. Eventuale Funzione eseguita dai thread
void* incrementa(void* arg) {
    
    //richiamo e rinomino la struct
    struct GlobalData* data = (struct GlobalData*)arg;  //ricorda, forse perchè è in una funzione void


    //4. Cose che deve fare la funzione 
    // Incrementa le variabili a e b per 100 volte    
    for (int i=0; i<100; i++) {
    
        pthread_mutex_lock(&mutex); // Blocca il mutex        
	    data->a++;
        data->b++;
        pthread_mutex_unlock(&mutex); // Sblocca il mutex    
    }
    
    pthread_exit(NULL);
}


//SECONDA PARTE

int main() {


    //1. Inizializza la struttura dati condivisa    
    struct GlobalData glob;
    glob.a = 0;
    glob.b = 0;
    

	//2. Inizializza il mutex dinamicamente    
        pthread_mutex_t* mutex = (pthread_mutex_t*)malloc(sizeof(pthread_mutex_t));
    	
        //controllli sull'allocazione
        if (mutex == NULL) {
        printf("Errore durante l'allocazione del mutex.\n");
        return 1;
    	}
    	
        if (pthread_mutex_init(mutex, NULL) != 0) {
        printf("Errore durante l'inizializzazione del mutex.\n");
        free(mutex);
        return 1;
    }
    
    
    //3. Crea i due thread    
    pthread_t td[N];

   
    for(int i=0; i<2; i++){
        if (pthread_create(&td[i], NULL, incrementa, (void*)&glob) != 0) {
            printf("Errore durante la creazione del thread 1.\n");
            pthread_mutex_destroy(mutex);
            free(mutex);
            return 1;
            }
    }

     for(int i=0; i<2; i++){

        if (pthread_join(td[i],   NULL) != 0) {
        printf("Errore durante l'attesa del thread 1.\n");
        pthread_mutex_destroy(mutex);
        free(mutex);
        return 1;
        }
    }
   
    
     /*
    pthread_t thread1, thread2

    //controlli sulla creazione dei thread
    if (pthread_create(&thread1, NULL, incrementa, (void*)&glob) != 0) {
        printf("Errore durante la creazione del thread 1.\n");
        pthread_mutex_destroy(mutex);
        free(mutex);
        return 1;
    }

    if (pthread_create(&thread2, NULL, incrementa, (void*)&glob) != 0) {
        printf("Errore durante la creazione del thread 2.\n");
        pthread_mutex_destroy(mutex);
        free(mutex);
        return 1;
    }
	
   
    // Attendi la terminazione dei thread    
	if (pthread_join(thread1, 	NULL) != 0) {
        printf("Errore durante l'attesa del thread 1.\n");
        pthread_mutex_destroy(mutex);
        free(mutex);
        return 1;
    }

    if (pthread_join(thread2, NULL) != 0) {
        printf("Errore durante l'attesa del thread 2.\n");
        pthread_mutex_destroy(mutex);
        free(mutex);
        return 1;
    }

     */
    

    //4. Stampa i valori delle variabili a e b    
    printf("Valore di a: %d\n", glob.a);
    printf("Valore di b: %d\n", glob.b);
    
    //5. Dealloca il mutex    
    pthread_mutex_destroy(mutex);
    free(mutex);
    return 0;
}
