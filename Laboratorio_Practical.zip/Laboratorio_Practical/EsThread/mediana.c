#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>



struct Matrice {
	int** data;
	int row;
	int col;
	int *vett;
	int mediana;
	int cond;
};

pthread_mutex_t mutex;
pthread_cond_t conde;

struct Matrice matrice1;

struct Matrice alloca_matrice(int row, int col) {
	struct Matrice matrice;
	matrice.row = row;
	matrice.col = col;

	matrice.data = (int**)malloc(row * sizeof(int*));
	for (int i = 0; i < row; i++) {
		matrice.data[i] = (int*)malloc(col * sizeof(int));

	}
	pthread_mutex_init(&mutex, NULL);
	return matrice;

}

void dealloca_matrice(struct Matrice matrice) {
	for (int i = 0; i < matrice.row; i++) {
		free(matrice.data[i]);
	}
	free(matrice.data);
	pthread_mutex_destroy(&mutex);
	pthread_cond_destroy(&conde);
}

void * mediana(void* arg) {
	int* index = (int*)arg;
	int mediana;
	pthread_mutex_lock(&mutex);
	if (matrice1.row % 2 == 0) {
		for (int j = matrice1.col/2-1; j < matrice1.col/2+1; j++) {
			mediana += matrice1.data[*index][j];
			
		}
		mediana = mediana / 2;
		printf("Sono %d e il valore e' %d\n", *index, mediana);
	}
			else {
				int mediana = (matrice1.row+1) / 2;
				printf("%d\n", matrice1.data[*index][mediana-1]);
			}
			
	
	
		
		pthread_mutex_unlock(&mutex);
		pthread_exit(NULL);
	
}


int main(int argc, char* argv[]) {
	int k = 8;
	int m =8;
	pthread_t thread[m];
	matrice1.row = k;
	matrice1.col = m;
	matrice1 = alloca_matrice(k,m);

	for (int i = 0; i < matrice1.row; i++) {
		for (int j = 0; j < matrice1.row; j++) {
			matrice1.data[i][j] = rand() % 10;
			printf("%d\t", matrice1.data[i][j]);
		}
		printf("\n");
	}
	printf("\n");


	for (int i = 0; i < matrice1.row; i++) {
		int* index = malloc(matrice1.row * sizeof(int));
		*index = i;
		pthread_create(&thread[i], NULL, mediana, index);

	}

	for (int i = 0; i < matrice1.row; i++) {
		pthread_join(thread[i], NULL);
	}
	dealloca_matrice(matrice1);

}