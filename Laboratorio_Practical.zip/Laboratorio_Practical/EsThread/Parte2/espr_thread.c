/* Scrivere un programma in C che calcoli in modo concorrente 
l'espressione 4x^4+2y^3+z^2-sqrt(b). Il valore complessivo
 dell'espressione deve essere determinato dal thread principale. 
 I valori delle variabili devono essere passati da riga di comando. 
 Ciascun thread finito di calcolare il proprio termine dell'espressione, 
 inserisce il proprio tid in un array di dimensione pari al numero di thread, 
 ad indicare l'ordine di terminazione. */


#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <math.h>
#include <unistd.h>


struct {

    pthread_mutex_t mutex1;
    pthread_cond_t cond;
    int x, y, z, b;
    int *vect;
    int k;
    int espressione; 

} shared = {PTHREAD_MUTEX_INITIALIZER, PTHREAD_COND_INITIALIZER};     //segue ordine della struct


//PROTOTIPI DI FUNZIONE
void * func1(void *);
void * func2(void *);    //stampa con il thread principale



//MAIN
int main(int argc, char * argv[]){



    pthread_t td1[shared.x];
    pthread_t td2;

    if (argc != 5){
        perror("Errore devi inserire 4 valori");
        exit(-1);
    }

    shared.x = atoi(argv[1]);
    shared.y = atoi(argv[2]);
    shared.z = atoi(argv[3]);
    shared.b = atoi(argv[4]);

    shared.vect = malloc(shared.x*sizeof(int));

    //creo i thread
    for(int i=0; i<shared.x; i++){
        int * index = malloc(sizeof(int));
        * index = i;    //indicizzo tramite la i del for
        pthread_create(&td1[i], NULL, func1, index);
    }

    pthread_create(&td2, NULL, func2, NULL);


    //gestisco le attese
    for(int i=0; i<shared.x; i++){
        pthread_join(td1[i], NULL);
    }

    
    pthread_join(td2, NULL);


    return 0;
}


void * func1 (void * arg){
    int * index = (int*)arg;       //passo a ogni thread il proprio indice
    
    pthread_mutex_lock(&shared.mutex1);
    shared.espressione = 4*pow(shared.x,4) + 2*pow(shared.y,3) + pow(shared.z,2) - sqrt(shared.b);
    shared.k++;
    shared.vect[*index] = pthread_self();
    pthread_mutex_unlock(&shared.mutex1);

    if(shared.k == shared.x){
        sleep(1);      //evitare l'attesa continua
        pthread_cond_signal(&shared.cond);
    }

    printf("sono il thread %d con pid: %d\n", *index, shared.vect[*index]);
    pthread_exit(0);
}


void * func2 (void * arg){

    pthread_mutex_lock(&shared.mutex1);
    pthread_cond_wait(&shared.cond, &shared.mutex1);
    printf("Il valore dell'espressione è: %d\n", shared.espressione); 
    pthread_mutex_unlock(&shared.mutex1);

    pthread_exit(0);
    
}









