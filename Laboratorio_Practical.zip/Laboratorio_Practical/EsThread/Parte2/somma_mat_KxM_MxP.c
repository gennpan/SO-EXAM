/*Si realizzi un programma in C e Posix utilizzi k thread per calcolare la somma di due matrici kxm e mxp. Non appena sarà calcolata 
la matrice prodotto, un k+1-esimo thread aggiuntivo, che era rimasto in attesa, provvede a stampare la matrice risultato. 
Le matrici devono essere allocate dinamicamente.*/
 
#include <stdlib.h>
#include <stdio.h>
#include <semaphore.h>
#include <pthread.h>
#include <fcntl.h>
 
struct {
    pthread_mutex_t mutex;
    pthread_cond_t cond;
    sem_t *sem;
    int **A;
    int **B;
    int **C;
    int k;
    int m;
    int p;
    int l;
    } shared = { PTHREAD_MUTEX_INITIALIZER, PTHREAD_COND_INITIALIZER};



void * func(void *arg);
void * func1(void *arg);
void NewMatrix(int **, int, int);
void DeallocateMatrix(int **, int);


 
int main( int argc, char *argv[]) {
 
    if(argc !=4) {
        printf("Errore devi inserire 3 numeri");
        return 1;
    }
    
    shared.k= atoi(argv[1]);
    shared.m=atoi(argv[2]);
    shared.p=atoi(argv[3]);
    
    sem_unlink("/my_semaphore");
    sem_close(shared.sem);
    
    shared.sem=sem_open("/my_semaphore", O_CREAT,0644, 1);
 
    shared.A= malloc(shared.k*sizeof(int*));
    for(int i=0;i<shared.k;i++){
        shared.A[i]=malloc(shared.m*sizeof(int));
    }
    
    shared.B= malloc(shared.m*sizeof(int*));
    for(int i=0;i<shared.m;i++){
        shared.B[i]=malloc(shared.p*sizeof(int));
    }
    
    
    shared.C= malloc(shared.k*sizeof(int*));
    for(int i=0;i<shared.k;i++){
        shared.C[i]=malloc(shared.m*sizeof(int));
    }
    
    NewMatrix(shared.A,shared.k,shared.m);
    NewMatrix(shared.B,shared.m,shared.p);
    NewMatrix(shared.C,shared.k,shared.m);


    pthread_t tids[shared.k];


    for(int i=0;i<shared.k;i++){
        int *index = malloc(shared.k*sizeof(int));
        *index = shared.k;
        pthread_create(&tids[i],NULL,func,index);
    }
    
    pthread_t tid;
    pthread_create(&tid,NULL,func1,NULL);
    
    pthread_join(tid,NULL);
    sem_unlink("/my_semaphore");
    sem_close(shared.sem);
 
    return 0;
    
}
 
void* func(void* arg) {
    int * index = (int*)arg;
    
    sem_wait(shared.sem);
    shared.l=0;
    for(int i=0;i<shared.k;i++){
        for(int j=0;j<shared.p;j++){
            shared.C[*index][j] += shared.A[*index][j] * shared.B[i][*index]; 
        }
    }
    shared.l++;
    sem_post(shared.sem);
    

    if(shared.l == shared.k){
        pthread_cond_signal(&shared.cond);
    }    
     
    pthread_exit(NULL);
}
 
void *func1(void *arg) {
    //controllo
    while(shared.l<shared.k){
        pthread_cond_wait(&shared.cond,&shared.mutex);
    }
        for(int i=0;i<shared.k;i++){
            for(int j=0;j<shared.p;j++){
                printf("[%d]", shared.C[i][j]);
            }
                printf("\n");
        }
        pthread_mutex_unlock(&shared.mutex);
        pthread_exit(NULL);
}

void NewMatrix (int** A, int rows, int cols){
    for (int i=0; i<rows; i++){
        for(int j=0; j<cols; j++){
            A[i][j] = rand() % 10;
            printf("[%d]\t", A[i][j]);
        }
        printf("\n");
    }
}


void DeallocateMatrix(int** A, int rows) {
    for(int i=0; i<rows; i++){
        free(A[i]);
    }
    free(A);
}