/*Si realizzi un programma in C e Posix sotto Linux che, con l'ausilio della libreria Pthread, lancia
  m thread concorrenti per cercare il minimo di ciascuna delle m righe di una matrice mxn di interi e
  scriverla in un array di dimensione m nella prima posizione libera disponibile. Un thread m+1-esimo
  , completato il lavoro dei primi m thread, provvede a cercare il massimo tra i minimi e a stamparlo.
  Usare semafori Posix basati su nome e variabili di condizione. La dimensione della matrice può essere
  fronita in input al programma in fase di esecuzione o da riga di comando.*/







#include "apue.h"
#include <pthread.h>
#include <semaphore.h>
#include <fcntl.h>

struct {

    pthread_mutex_t mutex;
    pthread_cond_t cond;
    sem_t *sem;

    int n;
    int m;
    int **matrice;
    int *mins;
    int cont;

}   shared = {PTHREAD_MUTEX_INITIALIZER, PTHREAD_COND_INITIALIZER};


//PROTOTIPI DI FUNZIONE
void * func(void*);
void * func2();



//MAIN
int main(int argc, char*argv[]) {

    if (argc != 3) {
        printf("Errore! Uso ./a.out m n\n");
        exit(1);
    }


    sem_unlink("CS");
    shared.sem = sem_open("CS",O_CREAT,S_IRUSR|S_IWUSR,1);
    if (shared.sem == SEM_FAILED) {
        perror("Errore nell'apertura del semaforo");
        exit(1);
    }
    
    shared.cont = 0;
    shared.m = atoi(argv[1]);
    shared.n = atoi(argv[2]);

    shared.matrice = malloc(shared.m *sizeof(int*));
    for (int i=0;i<shared.m;i++){
        shared.matrice[i] = malloc(shared.n *sizeof(int));
    }
        printf("\nEcco la tua matrice:\nRighe: %d Colonne: %d\n",shared.m,shared.n);
    

    //creazione matrice
    for(int i=0;i<shared.m;i++){
        for(int j=0;j<shared.n;j++) {
            shared.matrice[i][j] = rand()%20+10;
            printf("[%d] ",shared.matrice[i][j]);
        }
        printf("\n");
    }

    shared.mins = malloc(shared.m*sizeof(int));
  //  printf("matrice creata");


    pthread_t *tids = malloc(shared.m * sizeof(pthread_t));
    
    for (int i=0;i<shared.m;i++) {
        int *index = malloc(sizeof(int));
        *index = i;
        pthread_create(&tids[i],NULL,func,index);
    }
    pthread_create(&tids[shared.m],NULL,func2,NULL);


    for (int i=0;i<=shared.m;i++) {
        pthread_join(tids[i],NULL);
    }

    sem_close(shared.sem);
    sem_unlink("CS");
    for (int i=0;i<shared.m;i++) {
        free(shared.matrice[i]);
    }
    free(shared.matrice);


    return 0;
}


void *func(void* args) {
    int *index = (int*)args;
    int min = 200;
    sem_wait(shared.sem);
    for(int i=0;i<shared.n;i++) {
        if (shared.matrice[*index][i] < min) min = shared.matrice[*index][i];
    }
    shared.mins[*index] = min;
    shared.cont++;
    //printf("\nSono il thread %d e ho inserito il minimo. Cont: %d\n",*index,shared.cont);
    if (shared.cont == shared.m-1 ) {
            sleep(1);
            pthread_cond_signal(&shared.cond);
    }

    sem_post(shared.sem);
    pthread_exit(NULL);
}

void *func2() {
       pthread_mutex_lock(&shared.mutex);
       //printf("\nWEEEE\n");
       pthread_cond_wait(&shared.cond,&shared.mutex);
       int max = 0;
       sleep(1);
       printf("\nEcco il vettore dei minimi\n");
       for(int i=0;i<shared.m;i++) {
           printf("| %d | ",shared.mins[i]);
           if (shared.mins[i] > max) max = shared.mins[i];
    }
        printf("\nEcco il massimo tra i minimi: %d \n", max);
        pthread_mutex_unlock(&shared.mutex);
        pthread_exit(NULL);

}

