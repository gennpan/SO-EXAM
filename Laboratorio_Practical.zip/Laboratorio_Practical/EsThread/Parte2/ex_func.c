/*
    Sviluppare un programma sotto linux che generi n thread (n passato come input da terminale), generi una matrice n*n,
    i cui valori all'interno sono generati casualmente da un intervallo [0,255].
    Ogni thread è identificato da un valore intero 'i', ogni thread i-esimo calcola la media della riga i-esima della matrice,
    quando tutte le medie sono state calcolate, viene notificato al thread n+1 che provvederà a calcolare la somma totale di tutte le medie.
    Utilizzare i mutex e le variabili di condizione.
*/


#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <fcntl.h>
#include <unistd.h>

struct {
	pthread_mutex_t mutex;
	pthread_cond_t cond;
	sem_t *sem;
	int **Matrix;
	int n;
	int *vett;
	int k;
	} shared = { PTHREAD_MUTEX_INITIALIZER, PTHREAD_COND_INITIALIZER} ;
	
	
void *func(void* arg);	
void *func1(void* arg);

int main(int argc, char *argv[]){
	if(argc !=2){
		printf("errore devi inserire 1 numero");
		return 1;
	}
	srand(time(NULL));
	shared.k=0;
	shared.n=atoi(argv[1]);
	
	sem_unlink("/my_semaphore");
	sem_close(shared.sem);
	shared.sem=sem_open("/my_semaphore",O_CREAT, 0644,1);
	
	shared.Matrix = malloc(shared.n*sizeof(int*));
	for(int i=0;i<shared.n;i++){
		shared.Matrix[i]=malloc(shared.n*sizeof(int));
	}

	for(int i=0;i<shared.n;i++){
		for(int j=0;j<shared.n;j++){
			shared.Matrix[i][j] = rand()%255;
			printf("[%d]",shared.Matrix[i][j]);
			
		}
		printf("\n");
		printf("ciaooo");
	}

	shared.vett=malloc(shared.n*sizeof(int));
	
	pthread_t tids[shared.n];
	pthread_t tid;
	for(int j=0;j<shared.n;j++){
		int *i= malloc(sizeof(int));
		*i=j;
		pthread_create(&tids[j],NULL,func,i);
		
	}
	
	pthread_create(&tid,NULL,func1,NULL);
	
	
	for(int i=0;i<shared.n;i++) {
		pthread_join(tids[i],NULL);
	}
	
	pthread_join(tid,NULL);
	sem_unlink("/my_semaphore");
	sem_close(shared.sem);
	for(int i =0;i<shared.n;i++){
		free(shared.Matrix[i]);
		
	}
	
	free(shared.Matrix);
	printf("ciaoo");
	return 0;
	
}


void *func(void* arg){

	int *i = (int*)arg;
	int sum=0;
	
	for(int j=0;j<shared.n;j++){
		sum +=shared.Matrix[*i][j];
	}
	shared.k++;
	sum = sum/shared.n;
	sem_wait(shared.sem);
	shared.vett[*i]=sum;
	sem_post(shared.sem);
	if(shared.k==shared.n-1) {
		sleep(1);
		pthread_cond_signal(&shared.cond);
	}
	
	pthread_exit(NULL);	
	

}


void* func1(void* arg){
		pthread_cond_wait(&shared.cond,&shared.mutex);
		for(int j=0;j<shared.n;j++) {
			printf("[%d]",shared.vett[j]);
		}
		pthread_mutex_unlock(&shared.mutex);
		pthread_exit(NULL);
}

