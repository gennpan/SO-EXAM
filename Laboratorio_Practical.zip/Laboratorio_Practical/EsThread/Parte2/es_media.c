/*
    Sviluppare un programma sotto linux che generi n thread (n passato come input da terminale), generi una matrice n*n,
    i cui valori all'interno sono generati casualmente da un intervallo [0,255].
    Ogni thread � identificato da un valore intero 'i', ogni thread i-esimo calcola la media della riga i-esima della matrice,
    quando tutte le medie sono state calcolate, viene notificato al thread n+1 che provveder� a calcolare la somma totale di tutte le medie.
    Utilizzare i mutex e le variabili di condizione.
*/

#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>


struct Matrice {
    int** data;
    int n;
    int* vector;
    pthread_mutex_t mutex;
    pthread_cond_t cond;
    sem_t* sem;

};

struct Matrice matrice1;
//stampa_vettore(void* );

struct Matrice alloca_matrice(int n) {
    struct Matrice matrix;
    matrix.n = n;

    matrix.data = (int**)malloc(n * sizeof(int*));
    for (int i = 0; i < n; i++) {
        matrix.data[i] = (int*)malloc(n * sizeof(int));
    }
    pthread_mutex_init(&matrix.mutex, NULL);
    return matrix;
}

void dealloca_matrice(struct Matrice matrix) {
    for (int i = 0; i < matrix.n; i++) {
        free(matrix.data[i]);
    }
    free(matrix.data);
    pthread_mutex_destroy(&matrix.mutex);
}



void* media(void* arg) {
    //struct Matrice* matrice = (struct Matrice*)arg;
    int somma=0;
    int k = 0;
    int* index = (int *)arg;
    printf("sono il thread %d\n", *index);
    if (*index == matrice1.n) {
        pthread_cond_wait(&matrice1.cond, &matrice1.mutex);
        for (int i = 0; i < matrice1.n; i++) {
            printf("[%d]", matrice1.vector[i]);
        }
        pthread_mutex_unlock(&matrice1.mutex);
        pthread_exit(NULL);
    }
    
    pthread_mutex_lock(&matrice1.mutex);
        for (int j = 0; j < matrice1.n; j++) {
            somma += matrice1.data[*index][j];
    }
        somma = somma / matrice1.n;
    matrice1.vector[*index] = somma;
    pthread_mutex_unlock(&matrice1.mutex);

    pthread_exit(NULL);
}


int main(int argc, char* argv[]) {
    if (argc != 2) {
        perror("inserisci gli 1 argomento");
        return 1;
    }

    int n;
    n = atoi(argv[1]);
    matrice1.n = n;

    matrice1 = alloca_matrice(n);
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            matrice1.data[i][j] = rand() % 10;
            printf("%d\t", matrice1.data[i][j]);
        }
        printf("\n");
    }

    printf("\n");
    matrice1.vector = malloc(n * sizeof(int));
    
    pthread_t thread[n];
    pthread_t threadn1;
    for (int i = 0; i <= n; i++) {
        int* index = malloc(sizeof(int));
        *index = i;
        pthread_create(&thread[i], NULL, media, index);
       
    }

    for (int i = 0; i < n; i++) {
        pthread_join(thread[i], NULL);
    }
    pthread_cond_signal(&matrice1.cond);
    pthread_join(threadn1, NULL);

}


void* stampa_vettore(void* arg) {
    int* index = (int *)arg;
    printf("sono il thread %d\n", *index);
    if (*index == matrice1.n) {
        pthread_cond_wait(&matrice1.cond,&matrice1.mutex);
        for (int i = 0; i < matrice1.n; i++) {
            printf("[%d]", matrice1.vector[i]);
        }
        pthread_mutex_unlock(&matrice1.mutex);
        pthread_exit(NULL);
    }
}


    