#include<stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>



//questa struct mi permette di 'salvare' la matrice al suo interno e poi la passo ai thread 
//sfruttando poi il puntatore a tipo non specifico
struct Matrice {
    int** data;
    int row;
    int col;
    pthread_mutex_t mutex;
};


//PROTOTIPI FUNZIONI
void * Sum(void*);
void dealloca_matrice(struct Matrice matrice);
struct Matrice alloca_matrice(int row, int col);


struct Matrice matrice1;



int main(){

    int m = 5;
    int n = 5;
    void * thread_results[m];

    matrice1 = alloca_matrice(m,n);

    pthread_t threads[m];

    for(int i=0; i<m; i++){
        for( int j=0; j<n; j++){
            matrice1.data[i][j] = rand() % 10;
            printf("%d\t", matrice1.data[i][j]);
        }
        printf("\n");
    }


    for(int i=0; i<m; i++){
        pthread_create(&threads[i], NULL, Sum, (void*)&matrice1);
    }

    for(int i=0; i<m; i++){
        pthread_join(threads[i], &thread_results[i]);
    }

    printf("Somme delle righe: \n");
    for(int i=0; i<m; i++){
        int * row_sum = (int*)thread_results[i];
        printf("Somma della riga %d: %d\n", i, row_sum[i]);
        free(row_sum); //Dealloca l'array row_sum
    }

    dealloca_matrice(matrice1);

    return 0;


}




//DEFINIZIONE DI FUNZIONI
struct Matrice alloca_matrice(int row, int col) {
    struct Matrice matrice;
    matrice.row = row;
    matrice.col = col;

    matrice.data = (int**)malloc(row*sizeof(int*));
    for(int i=0; i<row; i++){
        matrice.data[i] = (int*)malloc(col*sizeof(int));
    }
    pthread_mutex_init(&matrice.mutex, NULL);

    return matrice;
}



void dealloca_matrice(struct Matrice matrice) {
    for(int i=0; i<matrice.row; i++){
        free(matrice.data[i]);
    }
    free(matrice.data);
    pthread_mutex_destroy(&matrice.mutex);
}


void * Sum(void* arg) {
    int N,M;
    struct Matrice *matrix = (struct Matrice *)arg;
    int * row_sum = (int*)malloc(matrix->row * sizeof(int));

    //Calcolo della somma delle righe 
    for(int i=0; i<matrix->row; i++){
        pthread_mutex_lock(&matrix->mutex);
        row_sum[i] = 0;
        for(int j=0; j< matrix->col; j++){
            row_sum[i] += matrix->data[i][j];
        }
        pthread_mutex_unlock(&matrix->mutex);
    }
    pthread_exit(row_sum);
}


