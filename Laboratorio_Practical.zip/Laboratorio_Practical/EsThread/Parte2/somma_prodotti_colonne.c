/* Si realizzi un programma che lancia M thread per calcolare la somma dei prodotti di 2 colonne mxm, 
l'iesimo thread dopo aver calcolato i prodotti delle colonne iesime delle due matrici inserisce il 
risultato in un array m-dimensionale in modo concorrente nella prima locazioen libera, non appena 
l'array sarà riempito un m+1-esimo thread che era in attesa stamperà il contenuto.Usare mutex e va cond.*/



#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

struct {
    pthread_mutex_t mutex;
    pthread_cond_t cond;
    int m;
    int **A;
    int **B;
    int *vett;
    int l;
    } shared = { PTHREAD_MUTEX_INITIALIZER, PTHREAD_COND_INITIALIZER };
    
//N.B: Non c'è bisogno di creare una terza matrice di appoggio.

void * func (void *args);
void * func1 (void *args);



int main(int argc, char* argv[]) {
    
    if(argc != 2) {
        perror("Devi inserire un numero.");
        return 1;
    }
    
    shared.m = atoi(argv[1]);
    pthread_t tids[shared.m];
    pthread_t tid;


    //alloco dinamicamente matrici
    shared.A = malloc(shared.m*sizeof(int*));
    for(int i=0;i<shared.m;i++){
        shared.A[i]=malloc(shared.m*sizeof(int));
    }
    shared.B = malloc(shared.m*sizeof(int*));
    for(int i=0;i<shared.m;i++){
        shared.B[i]=malloc(shared.m*sizeof(int));
    }


    
    //creo matrici
    for(int i=0;i<shared.m;i++){
        for(int j=0;j<shared.m;j++) {
            shared.A[i][j]=rand()%100;
            printf("[%d]",shared.A[i][j]);
        }
        printf("\n");
    }
    printf("\nMatrice 2: \n");

    for(int i=0;i<shared.m;i++){
        for(int j=0;j<shared.m;j++) {
            shared.B[i][j]=rand()%100;
            printf("[%d]",shared.B[i][j]);
        }
        printf("\n");
    }


    //alloco dinamicamente il vettore
    shared.vett=malloc(shared.m*sizeof(int));



    //creo i thread
    for(int i=0; i<shared.m;i++) {
        int *index = malloc(sizeof(int));
        *index = i;
        pthread_create(&tids[i],NULL,func,index);
    }
    pthread_create(&tid,NULL,func1,NULL);
    

    //gestisco le attese
    for(int i=0;i<shared.m;i++) {
        pthread_join(tids[i],NULL);
    }
    
    pthread_join(tid,NULL);
    

    //dealloco la memoria
    for(int j=0;j<shared.m;j++) {
        free(shared.A[j]);
    }
    free(shared.A);
    for(int j=0;j<shared.m;j++) {
        free(shared.B[j]);
    }
    free(shared.B);
    free(shared.vett);
    return 0;
        
}

void *func(void *args) {
    int *index = (int*)args;
    int sum=0;
    for(int i=0;i<shared.m;i++) {
        sum += shared.A[i][*index] *shared.B[i][*index];
    }
    
    pthread_mutex_lock(&shared.mutex);
    shared.l++;
    shared.vett[*index] = sum;
    while(shared.l == shared.m-1) {
        sleep(1);
        pthread_cond_signal(&shared.cond);
    }
    pthread_mutex_unlock(&shared.mutex);
    pthread_exit(NULL);
}

void *func1(void *args) {
    pthread_cond_wait(&shared.cond,&shared.mutex);
    printf("\nVettore finale:\n");
    for(int i=0;i<shared.m;i++) {
        printf("[%d]",shared.vett[i]);
    }
    pthread_mutex_unlock(&shared.mutex);
    printf("\n");
    pthread_exit(NULL);
    
}
    