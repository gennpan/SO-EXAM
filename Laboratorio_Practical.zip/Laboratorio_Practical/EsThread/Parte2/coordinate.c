#include <stdlib.h>
#include <stdio.h>
#include <semaphore.h>
#include <pthread.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdbool.h>

struct {
    pthread_mutex_t mutex;
    int **Matrix;
    int k;
} shared = {PTHREAD_MUTEX_INITIALIZER};

#define n 5
pthread_t tids[n];
bool flag = 1;
int h;
void *func(void *arg);

int main(int argc, char* argv[]) {
	int k =0;
    shared.Matrix = malloc(n * sizeof(int*));
    for (int i = 0; i < n; i++) {
        shared.Matrix[i] = malloc(n * sizeof(int));
    }

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            shared.Matrix[i][j] = rand() % 100;
            printf("[%d]", shared.Matrix[i][j]);
        }
        printf("\n");
    }

    for (int i = 0; i < n; i++) {
        int *index = malloc(sizeof(int));
        *index = i;
        pthread_create(&tids[i], NULL, func, index);
    }
    
    
    pthread_join(tids[h],NULL);
    	
    for(int i=0;i<n;i++){
    free(shared.Matrix[i]);
    }
    free(shared.Matrix);
    return 0;

}

void *func(void *arg) {
    int *index = (int*)arg;
    shared.k=92;
    pthread_mutex_lock(&shared.mutex);
 
    if(flag == 1) {
      h=*index;
    	for(int j=0;j<n;j++){
    		for (int i = 0; i < n; i++) {
     			if(shared.Matrix[j][i] == shared.k) {
     				printf("elemento trovato da [%d]\n",*index);
     				flag = 0;
     				
      			}
      		}
      	}
    
      	for(int i=0;i<n;i++){
      		if(i !=*index){
      			pthread_cancel(tids[i]);
      			printf("thread cancellato [%d]\n",i);
      		}
      	}
      }
      		
    pthread_mutex_unlock(&shared.mutex);
    pthread_exit(NULL);
}




