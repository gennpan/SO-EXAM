#include<stdio.h>
#include <stdlib.h>
#include <pthread.h>

//DICHIARO EVENTUALI COSTANTI PER LA CREAZIONE DEI THREAD
#define T 4


//PROTOTIPI FUNZIONI
//void* function(void*);
void NewMatrix(int**, int, int);
void ShowMatrix(int**, int, int);
void FreeMatrix(int**, int);
void* fun(void*);

//DICHIARO EVENTUALI STRUCT E VARIABILI
//struct GlobalData{
  //  int a;
  //  int b;
//}

//questa struct mi permette di 'salvare' la matrice al suo interno e poi la passo ai thread 
//sfruttando poi il puntatore a tipo non specifico
typedef struct{
    int n;
    int* row;
}container_t;


pthread_t thread[T];

int main(){

    int i,n=4;
    container_t args[n];


    /* allocazione dinamica matrice */
 int** matrix = (int**)malloc(n*sizeof(int*));
    for(i=0; i<n; i++)
        matrix[i] = (int*)malloc(n*sizeof(int));

    NewMatrix(matrix,n,n);


    for(i=0; i<T; i++){
        args[i].row = matrix[i];
        args[i].n = n;
        if(pthread_create(&thread[i], NULL, fun, (void*)&args[i]) != 0){
            printf("errore nella creazione del thread\n");
            return 1;
        }
    }

    ShowMatrix(matrix,n,n);
    FreeMatrix(matrix,n);
    exit(0);



}




//DEFINIZIONE DI FUNZIONI
void NewMatrix(int** A, int rows, int cols){
    int i,j;
    for(i=0; i<rows; i++){
        for(j=0; j<cols; j++){
            A[i][j] = rand() % 10;
        }
    }
    return;
}

void ShowMatrix(int** A, int rows, int cols){
    int i,j;
    for(i=0; i<rows; i++){
        for(j=0; j<cols; j++){
            printf("%d\t", A[i][j]);
        }
        printf("\n");
    }
    return;
}

void FreeMatrix(int** A, int rows){
    int i,j;
    for(i=0; i<rows; i++)
        free(A[i]);
            free(A);
        return;
    }

void* fun(void* cont){

}





