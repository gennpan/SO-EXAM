#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>


struct {
	pthread_mutex_t mutex;
	pthread_cond_t cond;
	int **A;
	int **B;
	int *vett;
	int m,k;
} shared = {PTHREAD_MUTEX_INITIALIZER, PTHREAD_COND_INITIALIZER};


//PROTOTIPI DI FUNZIONE
void * fun1(void *);
void * fun2(void *);


int main(int argc, char * argv[]){

	if(argc != 2){
		perror("Inserire la dimensione M utilizzata per entrambe le matrici.\n");
		exit(-1);
	}
	
	shared.m = atoi(argv[1]);
	pthread_t tds[shared.m];
	pthread_t td;
	
	//alloco memoria per le due matrici e per il vettore.
	shared.A = malloc(shared.m*sizeof(int*));
	for(int i=0; i<shared.m; i++){
		shared.A[i] = malloc(shared.m*sizeof(int));
	}
	
	shared.B = malloc(shared.m*sizeof(int*));
	for(int i=0; i<shared.m; i++){
		shared.B[i] = malloc(shared.m*sizeof(int));
	}
	
	shared.vett = malloc(shared.m*sizeof(int));
	
	
	//creo le due matrici usando valori casuali, con relativa stampa.
	printf("Matrice A:\n");
	for(int i=0; i<shared.m; i++){
		for(int j=0; j<shared.m; j++){
			shared.A[i][j] = rand() % 100;
			printf("[%d] ", shared.A[i][j]);
		}
		printf("\n");
	}
	printf("Matrice B:\n");
	for(int i=0; i<shared.m; i++){
		for(int j=0; j<shared.m; j++){
			shared.B[i][j] = rand() % 100;
			printf("[%d] ", shared.B[i][j]);
		}
		printf("\n");
	}
	printf("\n");
	
	
	//creo i threads effettuando anche i controlli, utilizzo la pthread_create().
	for(int i=0; i<shared.m; i++){
	int * index = malloc(sizeof(int));
	* index = i;
	if(pthread_create(&tds[i], NULL, fun1, index) != 0){
		perror("Errore durante la creazione dei threads.\n");
		exit(-2);
		}
	}
	
	if(pthread_create(&td, NULL, fun2, NULL) != 0){
		perror("Errore durante la creazione del singolo thread che si occupa della stampa.\n");
		exit(-3);
	}
	
	//gestisco le attese utilizzando la funzione pthread_join()
	for(int i=0; i<shared.m; i++){
	if(pthread_join(tds[i], NULL) != 0){
		perror("Errore durante la pthread_join() dei threads.\n");
		exit(-4);
		}
	}
	
	if(pthread_join(td, NULL) != 0){
		perror("Errore durante la pthread_join() del singolo thread.\n");
		exit(-5);
	}
	
	//dealloco la memoria per le matrici e per il vettore
	//sleep(2);  //mi assicuro che attendino un po' prima di deallocare la memoria
	for(int i=0; i<shared.m; i++){
		free(shared.A[i]);
	}	
	free(shared.A);
	for(int i=0; i<shared.m; i++){
		free(shared.B[i]);
	}	
	free(shared.B);
	free(shared.vett);
	exit(0);
}


//DEFINISCO LE FUNZIONI: fun1, fun2
void * fun1(void * args){
	int * index = (int*)args;
	int sum = 0;
	
	for(int i=0; i<shared.m; i++){
		sum += shared.A[i][*index] * shared.B[i][*index];
	}
	
	pthread_mutex_lock(&shared.mutex);
	shared.k++;
	shared.vett[*index] = sum;
	
	while(shared.k == shared.m){			//quando sei l'ultimo, attiva il secondo "processo"
	      	
	      	sleep(1);				//questa sleep, mi assicura che aspetti un po' prima di segnalare
	      	pthread_cond_signal(&shared.cond);
			
			pthread_mutex_unlock(&shared.mutex);	//devo rilasciare il mutex dopo aver segnalato
			pthread_exit(0);			//devo uscire dopo aver segnalato.
		}
	
	pthread_mutex_unlock(&shared.mutex);
	pthread_exit(0);
}




void * fun2(void * args){
	pthread_cond_wait(&shared.cond, &shared.mutex);
	for(int i=0; i<shared.m; i++){
		printf("[%d] ", shared.vett[i]);
	}
	printf("\n");
	pthread_mutex_unlock(&shared.mutex);
	pthread_exit(0);
}














