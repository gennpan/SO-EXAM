#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>


struct {
	pthread_mutex_t mutex;
	pthread_cond_t cond;
	int **A;
	int m,k;
} shared = {PTHREAD_MUTEX_INITIALIZER, PTHREAD_COND_INITIALIZER};


//PROTOTIPI DI FUNZIONE
void * fun1(void *);



int main(int argc, char * argv[]){

	if(argc != 2){
		perror("Inserire la dimensione M utilizzata per la matrice.\n");
		exit(-1);
	}
	
	shared.m = atoi(argv[1]);
	pthread_t tds[shared.m];

	
	//alloco memoria per le due matrici e per il vettore.
	shared.A = malloc(shared.m*sizeof(int*));
	for(int i=0; i<shared.m; i++){
		shared.A[i] = malloc(shared.m*sizeof(int));
	}
		
	
	//creo la matrice usando valori casuali, con relativa stampa.
	printf("Matrice A:\n");
	for(int i=0; i<shared.m; i++){
		for(int j=0; j<shared.m; j++){
			shared.A[i][j] = rand() % 100;
			printf("[%d] ", shared.A[i][j]);
		}
		printf("\n");
	}
	
	
	//creo i threads effettuando anche i controlli, utilizzo la pthread_create().
	for(int i=0; i<shared.m; i++){
	int * index = malloc(sizeof(int));
	* index = i;
	if(pthread_create(&tds[i], NULL, fun1, index) != 0){
		perror("Errore durante la creazione dei threads.\n");
		exit(-2);
		}
	}
	
	//gestisco le attese utilizzando la funzione pthread_join()
	for(int i=0; i<shared.m; i++){
	if(pthread_join(tds[i], NULL) != 0){
		perror("Errore durante la pthread_join() dei threads.\n");
		exit(-4);
		}
	}
	
	
	for(int i=0; i<shared.m; i++){
		free(shared.A[i]);
	}	
	free(shared.A);	
	exit(0);
}


//DEFINISCO LE FUNZIONI: fun1, fun2
void * fun1(void * args){
int* index = (int*)args;
	int mediana;
	pthread_mutex_lock(&shared.mutex);
	if (shared.m % 2 == 0) {
		for (int j = shared.m/2-1; j < shared.m/2+1; j++) {
			mediana += shared.A[*index][j];
			
		}
		mediana = mediana / 2;
		printf("Sono %d e il valore e' %d\n", *index, mediana);
	}
			else {
				int mediana = (shared.m+1) / 2;
				printf("%d\n", shared.A[*index][mediana-1]);
			}
			
	
	
		
		pthread_mutex_unlock(&shared.mutex);
		pthread_exit(NULL);
}


















