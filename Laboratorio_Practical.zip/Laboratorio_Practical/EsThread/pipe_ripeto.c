#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

#define R 0
#define W 1


int main(int argc, char * argv[]){

    int pfd[2], pid;

    if(pipe(pfd) == -1){        //creazione della pipe
        perror("pipe() Fallita.");
        exit(-1);
    }

    if((pid = fork()) < 0){       //creazione del figlio
        perror("fork() Falllita.");
        exit(-2);
    }



    if(pid == 0){        //padre
        close(pfd[R]);
        dup2(pfd[W], 0);
        close(pfd[W]);
        execlp("grep", "grep", argv[1], NULL);
        perror("grep Fallita.");
        exit(-3);
    } else {        //figlio
        close(pfd[W]);
        dup2(pfd[R], 0);
        close(pfd[R]);
        execlp("ls", "ls", argv[2], NULL);
        perror("ls Fallita.");
        exit(-4);
    }

}