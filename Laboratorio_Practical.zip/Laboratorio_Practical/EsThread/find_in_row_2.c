/*Si realizzi un programma in C e Posix sotto Linux che, utilizzando la libreria pthread,
  lancia n thread per cercare un elemento in una matrice nxn di interi. Ognuno dei thread
  cerca l'elemento in una delle righe della matrice. Non appena ha trovato l'elemento 
  cercato, rende note gli altri thread le coordinate dell'elemento e tutti i thread 
  terminano.(sono cancellati)*/



#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

#define N 5   //lancia N thread

void * ThreadCancel(int);    //dobbiamo cancellare i thread che terminano tramite pthread_cancel
void * FindInRow(void *);
void * stampa_elemento (void *);


//DEFINISCO LE STRUCT

struct {
    pthread_mutex_t mutex;
    pthread_cond_t cond;
    int **A;
    int tid;
    int *row;       //questo perchè la x deve essere cercata nelle righe
    int k;
    int xrow;
    int xcol;
} shared = {PTHREAD_MUTEX_INITIALIZER, PTHREAD_COND_INITIALIZER};


int x = 3;

pthread_t threads[N];
pthread_t tid2;


int main(int argc, char * argv[]){

       

    //alloco memoria per la matrice
    shared.A = malloc(N*sizeof(int*));
        for(int i=0; i<N; i++)
            shared.A[i] = malloc(N*sizeof(int));
    

    //creo matrice
    for(int i=0;i<N;i++){
        for(int j=0;j<N;j++) {
            shared.A[i][j]=rand()%10;
            printf("[%d]",shared.A[i][j]);
        }
        printf("\n");
    }
    

    //creo i thread
    for(int i=0; i<N; i++){
        int *index = malloc(sizeof(int));
        *index = i;
        if(pthread_create(&threads[i], NULL, FindInRow, index) != 0){
            printf("Errore durante la creazione del thread: %d", &threads[i]);
            return 1;
        }
    }

    
    if(pthread_create(&tid2, NULL, stampa_elemento, NULL) != 0){
            printf("Errore durante la creazione del thread: %d", &tid2);
            return 1;
        }


    

    //gestisco le attese
    for(int i=0; i<N; i++){
        if(pthread_join(threads[i], NULL) != 0){
            printf("Errore durante la join del thread: %d", &threads[i]);
            return 1;
        }
    }

 
    if(pthread_join(tid2, NULL) != 0){
            printf("Errore durante la join del thread: %d", &tid2);
            return 1;
    }
   

    //dealloco la memoria
    for(int i=0; i<N; i++) {
        free(shared.A[i]);
    }
    free(shared.A);
    return(0);
}



//DEFINISCO LE FUNZIONI
void * ThreadCancel(int cols){
    for(int i=0; i<cols; i++){
        if(threads[i] != pthread_self())
            pthread_cancel(threads[i]);
    }
}


void * FindInRow(void * args){
 
    shared.xrow = -1;
    int *index = (int*)args;

    for(int i=0; i<N; i++){
        for(int j=0; j<N; j++){
            if(shared.A[i][j] == x){
            pthread_mutex_lock(&shared.mutex);
            ThreadCancel(N);
            shared.xrow = i;
            shared.xcol = j;
            pthread_mutex_unlock(&shared.mutex);
        }
    }
    shared.k++;
    
    if(shared.k == N){   //se sei l'ultimo
            pthread_cond_signal(&shared.cond);
        }    
        pthread_exit(NULL);
    }
    pthread_exit(NULL);
}
   


void * stampa_elemento (void * arg){

    //aspetto finchè non sono l'ultimo
    while(shared.k < N){
        pthread_cond_wait(&shared.cond, &shared.mutex);
    }

    //stampo l'elemento e le sue coordinate
    if(shared.xrow != -1){
        printf("\nCoordinate di [%d]: (%d,%d)\n", x,shared.xrow,shared.xcol);
        printf("\nTrovato dal thread: [%d]\n", pthread_self());
        
            for(int i=0; i<N; i++){
                pthread_cancel(threads[i]);
                printf("thread cancellato: [%d]\n", threads[i]);
            }
        

        } else {
            printf("\nElemento %d non trovato... \n", x);
            }

        pthread_exit(NULL);
}
