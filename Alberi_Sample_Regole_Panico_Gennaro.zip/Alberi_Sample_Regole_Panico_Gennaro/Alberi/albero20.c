#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
#include <sys/types.h>
#include <signal.h>

int glob=4;
int pid=1;
int i;
int main(){
       signal(SIGCHLD,SIG_IGN);
       int stato;
	glob--;
	pid = fork();
	
	if (fork()){
		if (pid)
			glob--;
		else
			for (i = 1; i <= 2; i++)
				pid = fork();
		glob = glob + 2;
		glob--;
		fork();
	}
printf("Sono il processo %d, figlio di %d. GLOB = %d, pid = %d, i = %d\n",getpid(),getppid(),glob,pid,i);
wait(&stato);
exit(0);
}
