#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <signal.h>
#include <unistd.h>
int glob=5;
int pid = 0;
int main(){

        
	fork();
	glob--;
	if (fork()){
		glob--;
	}
		
	if (pid==0){
		pid=fork();
		glob--;
	}

	printf("Sono %d  figlio di %d, pid = %d, Glob: %d\n",getpid(),getppid(),pid,glob);
exit(0);
}
