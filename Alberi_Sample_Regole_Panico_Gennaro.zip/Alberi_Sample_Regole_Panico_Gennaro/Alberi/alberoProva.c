#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int glob = 5;
int pid = 0;

int main ()
{
	int i;
	for (i = 1; i <= glob; i ++)
	{
		pid = fork();
		if (pid)
		{
			glob = glob - 1;
		}

		glob = glob - 1;
	}

	printf ("Process %d, glob = %d i = %d\n", getpid(), glob, i);
}
