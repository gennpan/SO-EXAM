#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
int glob=20;
int pid=0;


int main(){
	int i=0;

	for(i=2; i<4; i++){
		pid = fork();
		if (pid==0){
			glob = glob*2;
			sleep(i+1);
		}
		glob = glob-1;
	}
	printf("valore di glob = %d\n\n", glob);
}
