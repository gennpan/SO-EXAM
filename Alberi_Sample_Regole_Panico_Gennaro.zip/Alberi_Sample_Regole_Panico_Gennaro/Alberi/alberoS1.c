#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
int glob=4;
int pid=1;

int main(){
		fork();
		glob++;
		if (!fork()){
			pid = fork();
			glob = glob*2;
		}
		if (!pid){
			fork();
			glob = glob-2;
		} 
	glob++;
	
	printf ("Process %d, glob = %d\n\n", getpid(), glob);
}


