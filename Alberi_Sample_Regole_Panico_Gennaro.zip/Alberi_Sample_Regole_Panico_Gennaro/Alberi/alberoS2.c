#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
int glob=7;
int pid=0;
int i;

int main(){
	for(i=1; i<3; i++){
		if (pid = fork())
			fork();
		if (pid)
			glob = glob-1;
}
	printf ("Process %d, glob = %d, i = %d\n\n", getpid(), glob, i);
}